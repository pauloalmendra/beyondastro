# test_sensors.py
from sensors import SunSensor

def test_sun_sensor():
    sensor = SunSensor(noise_std=0.05)
    attitude = [1, 0, 0, 0]  # Mock attitude quaternion
    reading = sensor.read(attitude)
    assert len(reading) == 3  # Should return a 3D vector
