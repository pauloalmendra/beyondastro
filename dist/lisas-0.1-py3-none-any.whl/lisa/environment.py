# environment.py
class ExternalTorques:
    @staticmethod
    def gravity_gradient(satellite):
        # Calculate the gravity gradient torque
        return [0, 0, 0]  # Mock value
    
    @staticmethod
    def aerodynamic_drag(satellite):
        # Calculate drag torque
        return [0, 0, 0]  # Mock value
